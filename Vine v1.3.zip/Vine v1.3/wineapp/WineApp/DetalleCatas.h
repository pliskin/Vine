//
//  DetalleCatas.h
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 8/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetalleFinalCatas.h"

@interface DetalleCatas : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *Alcohol;
@property (weak, nonatomic) IBOutlet UITextField *Ash;
@property (weak, nonatomic) IBOutlet UITextField *Alcalinity;
@property (weak, nonatomic) IBOutlet UITextField *Flavanoid;
@property (weak, nonatomic) IBOutlet UITextField *Nonflavanoid;
@property (weak, nonatomic) IBOutlet UITextField *Proanthocyanins;
@property (weak, nonatomic) IBOutlet UITextField *Color;
@property (weak, nonatomic) IBOutlet UITextField *Hue;
@property (weak, nonatomic) IBOutlet UITextField *OD280;
@property (weak, nonatomic) IBOutlet UITextField *Proline;

@property (nonatomic) int id_Usuario_NuevaCata;
@property (nonatomic) NSString *nombre_Usuario_NuevaCata;
@property (nonatomic) NSString *nombre_Avatar_DetalleCatas;

- (IBAction)pasarFinalizarCata:(id)sender;

@end
