//
//  GestorBD.h
//  SQLITE
//
//  Created by Francisco Jose Escamez Martin on 10/11/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GestorBD : NSObject

@property (nonatomic, strong) NSMutableArray *arrNombresCols;
@property (nonatomic) int filasAfectadas;
@property (nonatomic) long long ultimoID;

- (instancetype) initWithDatabaseFilename: (NSString *) dbFileName;
- (NSArray*) selectFromDB:(NSString *) consulta;
- (void) executeQuery: (NSString *) consulta;

@end
