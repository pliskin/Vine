//
//  Avatar.m
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 20/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import "Avatar.h"

@interface Avatar ()

@end

@implementation Avatar

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


- (IBAction)avatar1:(id)sender
{
    self.avatar.image = [UIImage imageNamed:@"cara1.jpeg"];
    self.nombreImagen = @"cara1.jpeg";
}

- (IBAction)avatar2:(id)sender
{
    self.avatar.image = [UIImage imageNamed:@"cara2.jpeg"];
    self.nombreImagen = @"cara2.jpeg";
}

- (IBAction)avatar3:(id)sender
{
    self.avatar.image = [UIImage imageNamed:@"cara3.jpeg"];
    self.nombreImagen = @"cara3.jpeg";
}

- (IBAction)avatar4:(id)sender
{
    self.avatar.image = [UIImage imageNamed:@"cara4.jpeg"];
    self.nombreImagen = @"cara4.jpeg";
}

- (IBAction)avatar5:(id)sender
{
    self.avatar.image = [UIImage imageNamed:@"cara5.jpeg"];
    self.nombreImagen = @"cara5.jpeg";
}

- (IBAction)avatar6:(id)sender
{
    self.avatar.image = [UIImage imageNamed:@"cara6.jpeg"];
    self.nombreImagen = @"cara6.jpeg";
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    DetalleUsuario *destino1= [segue destinationViewController];
    destino1.avatar.image = self.avatar.image;
    destino1.nombre_Avatar_DetalleUsuario = self.nombreImagen;
}

@end
