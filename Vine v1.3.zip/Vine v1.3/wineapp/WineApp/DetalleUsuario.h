//
//  DetalleUsuario.h
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 30/11/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Avatar.h"

@protocol DetailViewControllerDelegate

- (void) editionDidFinished;

@end

@interface DetalleUsuario : UIViewController //<UINavigationControllerDelegate, UIImagePickerControllerDelegate>

@property (weak, nonatomic) IBOutlet UITextField *nombre;
@property (weak, nonatomic) IBOutlet UISegmentedControl *sexo;
@property (weak, nonatomic) IBOutlet UIDatePicker *nacimiento;
@property (weak, nonatomic) IBOutlet UIImageView *avatar;

@property (nonatomic) NSString *nombre_Avatar_DetalleUsuario;

@property (nonatomic, strong) id<DetailViewControllerDelegate> delegate;

- (IBAction) guardarDatos: (id)sender;
- (IBAction) pickImage:(id)sender;

@end
