//
//  Usuarios.h
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 30/11/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetalleUsuario.h"
#import "CatasUsuario.h"

@interface Usuarios : UIViewController <UITableViewDataSource, UITableViewDelegate, DetailViewControllerDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tablaUsuarios;

- (IBAction)insertarUsuario:(id)sender;

@end
