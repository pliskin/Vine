//
//  vertical.h
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 19/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface vertical : UIViewController

@property int numberOfLines;
@property UILabel *text;


@end
