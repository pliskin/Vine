//
//  CeldaPersonalizada.m
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 21/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import "CeldaPersonalizada.h"

@implementation CeldaPersonalizada

- (void)awakeFromNib
{
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
