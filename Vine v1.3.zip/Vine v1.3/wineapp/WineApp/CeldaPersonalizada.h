//
//  CeldaPersonalizada.h
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 21/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CeldaPersonalizada : UITableViewCell

@end
