//
//  DetalleUsuario.m
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 30/11/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import "DetalleUsuario.h"
#import "GestorBD.h"

@interface DetalleUsuario ()

@property (nonatomic, strong) GestorBD *gestorBD;
@property (nonatomic ) int contador;

- (IBAction) ocultarTeclado:(id)sender;

@end

@implementation DetalleUsuario

- (IBAction)unwindToThisViewController:(UIStoryboardSegue *)unwindSegue
{
   self.avatar.image = [UIImage imageNamed:self.nombre_Avatar_DetalleUsuario];
}

//Vista de la vista//
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.gestorBD = [[GestorBD alloc] initWithDatabaseFilename:@"vinos.sqlite"];
    _contador = 0;
    self.nombre_Avatar_DetalleUsuario=@"";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

//Guarda los datos del usuario en la BBDD//
- (IBAction) guardarDatos:(id) sender
{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"dd-MM-yyyy"];
    NSString *fecha_nacimiento = [df stringFromDate:self.nacimiento.date];
    
    if ([self.nombre.text isEqualToString: @""])
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Advertencia" message:@"Introduzca un nombre de Usuario"preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *accion = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
        {
            [alert dismissViewControllerAnimated:YES completion:nil];
        }];
        [alert addAction:accion];
        [self presentViewController:alert animated:YES completion:nil];
        NSLog(@"El nombre no puede estar vacio.....");
    }
    else
    {
        if ([self.nombre_Avatar_DetalleUsuario isEqualToString: @""])
        {
            if (_contador<2)
            {
                _contador=_contador+1;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Advertencia" message:@"No ha seleccionado un Avatar"preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *accion = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                    {
                        [alert dismissViewControllerAnimated:YES completion:nil];
                    }];
                [alert addAction:accion];
                [self presentViewController:alert animated:YES completion:nil];
            }
            if (_contador==1)
            {
             self.nombre_Avatar_DetalleUsuario = @"ios.jpeg";
            }
        }
        else
        {
            NSString *consulta = [NSString stringWithFormat:@"insert into usuarios values (null, '%@','%ld','%@', '%@')", self.nombre.text, self.sexo.selectedSegmentIndex, fecha_nacimiento, self.nombre_Avatar_DetalleUsuario];
            [self.gestorBD executeQuery:consulta];
            if (self.gestorBD.filasAfectadas !=0)
            {
                NSLog(@"Consulta ejecutada con ÉXITO...%d filas", self.gestorBD.filasAfectadas);
                [self.navigationController popViewControllerAnimated:YES];
                [self.delegate editionDidFinished];
            }
            else
            {
                NSLog(@"No se ha podido ejecutar la consulta...repásala...");
            }
        }
    }
}


- (IBAction) ocultarTeclado:(id)sender
{
    [self.nombre resignFirstResponder];
}
- (IBAction)pickImage:(id)sender
{
    
}

@end
