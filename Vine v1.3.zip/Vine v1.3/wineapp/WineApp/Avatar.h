//
//  Avatar.h
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 20/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetalleUsuario.h"

@interface Avatar : UIViewController

- (IBAction)avatar1:(id)sender;
- (IBAction)avatar2:(id)sender;
- (IBAction)avatar3:(id)sender;
- (IBAction)avatar4:(id)sender;
- (IBAction)avatar5:(id)sender;
- (IBAction)avatar6:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *uno;


@property (nonatomic) UIImageView *avatar;
@property (nonatomic) NSString *nombreImagen;

@end
