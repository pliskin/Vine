//
//  DetalleCatas.m
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 8/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import "DetalleCatas.h"
#import "DetalleFinalCatas.h"

@interface DetalleCatas ()

@end

@implementation DetalleCatas
- (IBAction)Alcohol:(id)sender
{
    UISlider *variable_alcohol = (UISlider *) sender;
    NSString *valor_alcohol = [NSString stringWithFormat:@"%.2f", variable_alcohol.value];
    self.Alcohol.text = valor_alcohol;
}
- (IBAction)Ash:(id)sender
{
    UISlider *variable_ash = (UISlider *) sender;
    NSString *valor_ash = [NSString stringWithFormat:@"%.2f", variable_ash.value];
    self.Ash.text = valor_ash;
}
- (IBAction)Alcalinity:(id)sender
{
    UISlider *variable_alcalinity = (UISlider *) sender;
    NSString *valor_alcalinity = [NSString stringWithFormat:@"%.2f", variable_alcalinity.value];
    self.Alcalinity.text = valor_alcalinity;
}
- (IBAction)Flavanoids:(id)sender
{
    UISlider *variable_flavanoids = (UISlider *) sender;
    NSString *valor_flavanoids = [NSString stringWithFormat:@"%.2f", variable_flavanoids.value];
    self.Flavanoid.text = valor_flavanoids;
}
- (IBAction)Nonflavanoids:(id)sender
{
    UISlider *variable_Nonflavanoids = (UISlider *) sender;
    NSString *valor_Nonflavanoids = [NSString stringWithFormat:@"%.2f", variable_Nonflavanoids.value];
    self.Nonflavanoid.text = valor_Nonflavanoids;
}
- (IBAction)Proanthocyanins:(id)sender
{
    UISlider *variable_Proanthocyanins = (UISlider *) sender;
    NSString *valor_proanthocyanins = [NSString stringWithFormat:@"%.2f", variable_Proanthocyanins.value];
    self.Proanthocyanins.text = valor_proanthocyanins;
}
- (IBAction)Color:(id)sender
{
    UISlider *variable_color = (UISlider *) sender;
    NSString *valor_color = [NSString stringWithFormat:@"%.2f", variable_color.value];
    self.Color.text = valor_color;
}
- (IBAction)Hue:(id)sender
{
    UISlider *variable_hue = (UISlider *) sender;
    NSString *valor_hue = [NSString stringWithFormat:@"%.2f", variable_hue.value];
    self.Hue.text = valor_hue;
}
- (IBAction)OD280:(id)sender
{
    UISlider *variable_OD280 = (UISlider *) sender;
    NSString *valor_OD280 = [NSString stringWithFormat:@"%.2f", variable_OD280.value];
    self.OD280.text = valor_OD280;
}
- (IBAction)Proline:(id)sender
{
    UISlider *variable_proline = (UISlider *) sender;
    NSString *valor_proline = [NSString stringWithFormat:@"%f", variable_proline.value];
    self.Proline.text = valor_proline;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.Alcohol.text=@"13.00";
    self.Ash.text=@"2.30";
    self.Alcalinity.text=@"20.00";
    self.Flavanoid.text=@"2.00";
    self.Nonflavanoid.text=@"0.30";
    self.Proanthocyanins.text=@"1.60";
    self.Color.text=@"5.00";
    self.Hue.text=@"1.00";
    self.OD280.text=@"2.50";
    self.Proline.text=@"680.00";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

//Prepara el segue del siguiente//
- (IBAction)pasarFinalizarCata:(id)sender
{

}

//Prepara los segues entre las vistas destino//
- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"idSegueAtributosFinal"]) {
        DetalleFinalCatas *destino2 = [segue destinationViewController];
        destino2.id_Usuario_Detalle_NuevaCata = self.id_Usuario_NuevaCata;
        destino2.nombre_Usuario_Detalle_NuevaCata = self.nombre_Usuario_NuevaCata;
        destino2.nombre_Avatar = self.nombre_Avatar_DetalleCatas;
        destino2.at1 = self.Alcohol.text;
        destino2.at2 = self.Ash.text;
        destino2.at3 = self.Alcalinity.text;
        destino2.at4 = self.Flavanoid.text;
        destino2.at5 = self.Nonflavanoid.text;
        destino2.at6 = self.Proanthocyanins.text;
        destino2.at7 = self.Color.text;
        destino2.at8 = self.Hue.text;
        destino2.at9 = self.OD280.text;
        destino2.at10 = self.Proline.text;
    }
}

@end
