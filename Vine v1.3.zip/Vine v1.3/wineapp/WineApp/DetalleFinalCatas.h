//
//  DetalleFinalCatas.h
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 13/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DetailViewControllerDelegate2

- (void) editionDidFinished;

@end

@interface DetalleFinalCatas : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *usuario;
@property (weak, nonatomic) IBOutlet UISegmentedControl *clase;
@property (weak, nonatomic) IBOutlet UITextField *nombreCata;
@property (weak, nonatomic) IBOutlet UIDatePicker *fechaCata;
@property (weak, nonatomic) IBOutlet UIImageView *avatarUsuario;

@property (nonatomic, strong) id<DetailViewControllerDelegate2> delegate2;

@property (nonatomic) int id_Usuario_Detalle_NuevaCata;
@property (nonatomic) NSString *nombre_Usuario_Detalle_NuevaCata;
@property (nonatomic) NSString *nombre_Avatar;
@property (nonatomic) NSString *at1;
@property (nonatomic) NSString *at2;
@property (nonatomic) NSString *at3;
@property (nonatomic) NSString *at4;
@property (nonatomic) NSString *at5;
@property (nonatomic) NSString *at6;
@property (nonatomic) NSString *at7;
@property (nonatomic) NSString *at8;
@property (nonatomic) NSString *at9;
@property (nonatomic) NSString *at10;

- (IBAction) guardarNuevaCata: (id)sender;

@end
