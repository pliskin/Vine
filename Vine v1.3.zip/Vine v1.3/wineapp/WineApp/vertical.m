//
//  vertical.m
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 19/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import "vertical.h"

@interface vertical ()

@end

@implementation vertical

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    
    if (self) {
        self.numberOfLines = 0;
    }
    
    return self;
}

- (void)setText:(NSString *)text {
    NSMutableString *newString = [NSMutableString string];
    
    for (int i = text.length-1; i >= 0; i--) {
        [newString appendFormat:@"%c\n", [text characterAtIndex:i]];
    }
    
    super.text = newString;
}

@end


