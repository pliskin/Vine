//
//  Caratula.m
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 30/11/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import "Caratula.h"

@interface Caratula ()

@end

@implementation Caratula

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
