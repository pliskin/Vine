//
//  CatasUsuario.h
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 8/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetalleCatas.h"
#import "ResumenCata.h"

@interface CatasUsuario : UIViewController <UITableViewDataSource, UITableViewDelegate, DetailViewControllerDelegate2>

@property (weak, nonatomic) IBOutlet UITableView *tablaCatas;
@property (weak, nonatomic) IBOutlet UILabel *labelUsuario;
@property (weak, nonatomic) IBOutlet UILabel *barra;

@property (nonatomic) int id_Usuario_Catas;
@property (nonatomic) NSString *nombre_Usuario_Catas;
@property (nonatomic) NSString *nombre_Avatar_CatasUsuario;

- (IBAction)insertarCata:(id)sender;

@end
