//
//  CatasUsuario.m
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 8/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import "CatasUsuario.h"
#import "GestorBD.h"
#import "DetalleCatas.h"

@interface CatasUsuario ()

@property (nonatomic, strong) GestorBD* gestorBD;
@property (nonatomic, strong) NSArray* arrayDatos;

@property (nonatomic) int id_cata_seleccionada;

- (void) cargarCatas;

@end

@implementation CatasUsuario

//Vuelve a tomar el control desde la vista ResumenCata
- (IBAction)unwindToThisViewController:(UIStoryboardSegue *)unwindSegue
{
    [self.tablaCatas reloadData];
}

//Metodo para transformar el texto en vertical
- (NSString *)transformStringToVertical:(NSString *)originalString
{
    NSMutableString *mutableString = [NSMutableString stringWithString:originalString];
    NSRange stringRange = [mutableString rangeOfString:mutableString];
    for (int i = 1; i < stringRange.length*2; i+=2)
    {
        [mutableString insertString:@"\n" atIndex:i];
    }
    return mutableString;
}

//Vista inicial//
- (void)viewDidLoad
{
    [super viewDidLoad];
    NSString *concatenarUsuario = [NSString stringWithFormat:@"Usuario ||◊%@", self.nombre_Usuario_Catas];
    self.tablaCatas.delegate = self;
    self.tablaCatas.dataSource = self;
    self.gestorBD = [[GestorBD alloc] initWithDatabaseFilename:@"vinos.sqlite"];
    [self cargarCatas];
    
    self.labelUsuario.text = [self transformStringToVertical:concatenarUsuario];
    CGRect labelFrame = self.labelUsuario.frame;
    labelFrame.size.width  = self.labelUsuario.font.pointSize;
    labelFrame.size.height = self.labelUsuario.font.lineHeight * concatenarUsuario.length;
    self.labelUsuario.frame = labelFrame;
}

//Carga la tabla de catas de un usuario//
- (void) cargarCatas
{
    NSString *consulta = [NSString stringWithFormat:@"select * from catas where user_id=%i", self.id_Usuario_Catas];
    if (self.arrayDatos != nil) self.arrayDatos = nil;
    self.arrayDatos = [[NSArray alloc] initWithArray:[self.gestorBD selectFromDB:consulta]];
    [self.tablaCatas reloadData];
}

//Accion cuando los metodos terminan y vuelve el control a la vista//
- (void) editionDidFinished
{
    [self cargarCatas];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

//Prepara el segue del boton +//
- (IBAction)insertarCata:(id)sender
{

}

//Numero de secciones de la tabla//
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

//Numero de elementos de la tabla//
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.arrayDatos.count;
}

//Mostrar celdas
- (UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *celda = [tableView dequeueReusableCellWithIdentifier:@"cata" forIndexPath:indexPath];

    NSInteger indexOfFecha = [self.gestorBD.arrNombresCols indexOfObject:@"fecha_cata"];
    NSInteger indexOfNombre = [self.gestorBD.arrNombresCols indexOfObject:@"nombre_cata"];
    celda.textLabel.text = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:indexOfNombre]];
    NSInteger indexOfClase = [self.gestorBD.arrNombresCols indexOfObject:@"clase"];
    
    celda.textLabel.text = [NSString stringWithFormat:@"%@ (%@)", [[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:indexOfNombre],[[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:indexOfClase]];
    celda.detailTextLabel.text = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:indexOfFecha]];
    return celda;
}

//Borrar catas//
- (void) tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    int idRegistro;
    NSString *consulta;
    if (editingStyle != UITableViewCellEditingStyleDelete) return;
    idRegistro = [[[self.arrayDatos objectAtIndex:indexPath.row] objectAtIndex:0]intValue];
    consulta = [NSString stringWithFormat:@"delete from catas where id_cata=%d",idRegistro];
    [self.gestorBD executeQuery:consulta];
    [self cargarCatas];
}

//Prepara los segues entre las vistas destino//
- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"idSegueCrearCata"])
    {
        DetalleCatas *destino1 = [segue destinationViewController];
        destino1.id_Usuario_NuevaCata = self.id_Usuario_Catas;
        destino1.nombre_Usuario_NuevaCata = self.nombre_Usuario_Catas;
        destino1.nombre_Avatar_DetalleCatas = self.nombre_Avatar_CatasUsuario;
    }
    else if ([[segue identifier] isEqualToString:@"idSegueMostrarResumenCata"])
    {
        ResumenCata *destino2 = [segue destinationViewController];
        destino2.id_Resumen_Catas = self.id_cata_seleccionada;
        destino2.nombre_Usuario_Resumen_Catas = self.nombre_Usuario_Catas;
        destino2.nombre_Avatar_ResumenCata= self.nombre_Avatar_CatasUsuario;
    }
}

//Cuando retoma el control, recarga la tabla
- (void) viewWillAppear:(BOOL)animated
{
    [self cargarCatas];
}

//Prepara el segue del boton de la celda//
- (void) tableView: (UITableView *) tableView accessoryButtonTappedForRowWithIndexPath: (NSIndexPath *)indexPath
{
    self.id_cata_seleccionada = [[[self.arrayDatos objectAtIndex:indexPath.row] objectAtIndex:0]intValue];
    [self performSegueWithIdentifier:@"idSegueMostrarResumenCata" sender:self];
}

//Prepara el segue del boton de la celda//
- (void) tableView: (UITableView *) tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    self.id_cata_seleccionada = [[[self.arrayDatos objectAtIndex:indexPath.row] objectAtIndex:0]intValue];
    [self performSegueWithIdentifier:@"idSegueMostrarResumenCata" sender:self];
    
}

//Colorea las celdas
- (void)tableView: (UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath: (NSIndexPath *)indexPath
{
    if (indexPath.row %2 == 0)
    {
        cell.backgroundColor = [UIColor yellowColor];
    }
    else
    {
        cell.backgroundColor = [UIColor greenColor];
    }
}

@end
