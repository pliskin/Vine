//
//  Usuarios.m
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 30/11/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import "Usuarios.h"
#import "GestorBD.h"
#import "Caratula.h"

@interface Usuarios ()

@property (nonatomic, strong) GestorBD *gestorBD;
@property (nonatomic, strong) NSArray *arrayDatos;

@property (nonatomic) int id_Usuario;
@property (nonatomic) NSString *nombre_Usuario;
@property (nonatomic) NSString *nombre_Avatar_Usuario;


- (void) cargarUsuarios;

@end

@implementation Usuarios

//Vista inicial//
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tablaUsuarios.delegate = self;
    self.tablaUsuarios.dataSource = self;
    self.gestorBD = [[GestorBD alloc] initWithDatabaseFilename:@"vinos.sqlite"];
    [self cargarUsuarios];
}

//Borrar usuarios//
- (void) tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    int idRegistro;
    NSString *consulta;
    if (editingStyle != UITableViewCellEditingStyleDelete) return;
    idRegistro = [[[self.arrayDatos objectAtIndex:indexPath.row] objectAtIndex:0]intValue];
    consulta = [NSString stringWithFormat:@"delete from usuarios where id_usuario=%d",idRegistro];
    [self.gestorBD executeQuery:consulta];
    consulta = [NSString stringWithFormat:@"delete from catas where user_id=%d",idRegistro];
    [self.gestorBD executeQuery:consulta];
    [self cargarUsuarios];
}

//Prepara los segues entre las vistas destino//
- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"idSegueInicio"]) {
        [segue destinationViewController];
    }
    else if ([[segue identifier] isEqualToString:@"idSegueInsertarCata"])
    {
        CatasUsuario *destino2= [segue destinationViewController];
        destino2.id_Usuario_Catas = self.id_Usuario;
        destino2.nombre_Usuario_Catas = self.nombre_Usuario;
        destino2.nombre_Avatar_CatasUsuario = self.nombre_Avatar_Usuario;
    }
    else
    {
        DetalleUsuario *destino = [segue destinationViewController];
        destino.delegate = self;
    }
}

//Accion cuando vuelve el control a la vista//
- (void) editionDidFinished
{
    [self cargarUsuarios];
}

//Carga la tabla de usuarios//
- (void) cargarUsuarios
{
    NSString *consulta = @"select * from usuarios";
    if (self.arrayDatos != nil) self.arrayDatos = nil;
    self.arrayDatos = [[NSArray alloc] initWithArray:[self.gestorBD selectFromDB:consulta]];
    [self.tablaUsuarios reloadData];
}

//Numero de secciones de la tabla//
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

//Numero de elementos de la tabla//
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.arrayDatos.count;
}

//Datos de las celdas de Usuarios//
- (UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    NSInteger indexOfNombre = [self.gestorBD.arrNombresCols indexOfObject:@"nombre"];
    NSInteger indexOfSexo = [self.gestorBD.arrNombresCols indexOfObject:@"sexo"];
    NSInteger indexOfNacimiento = [self.gestorBD.arrNombresCols indexOfObject:@"fecha"];
    NSInteger indexOfFoto = [self.gestorBD.arrNombresCols indexOfObject:@"foto"];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:indexOfNombre]];
    NSString *sexo = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:indexOfSexo]];
    NSString *fecha = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:indexOfNacimiento]];
    NSString *sexoFinal;
    if ([sexo  isEqual: @"0"]){
        sexoFinal = @"Hombre";
        [cell setBackgroundColor:[UIColor blueColor]];
    }
    else {
        sexoFinal = @"Mujer";
         [cell setBackgroundColor:[UIColor magentaColor]];
    }
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@/%@",sexoFinal,fecha];
    if ([sexoFinal isEqualToString:@"Hombre"]){
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.detailTextLabel.textColor = [UIColor whiteColor];
    }
    self.nombre_Avatar_Usuario = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:indexOfFoto]];
    cell.imageView.image = [UIImage imageNamed:self.nombre_Avatar_Usuario];
    return cell;
}

//Prepara el segue del boton de la celda//

- (void) tableView: (UITableView *) tableView accessoryButtonTappedForRowWithIndexPath: (NSIndexPath *)indexPath {
    self.id_Usuario = [[[self.arrayDatos objectAtIndex:indexPath.row] objectAtIndex:0]intValue];
    self.nombre_Usuario = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:1]];
    self.nombre_Avatar_Usuario = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:4]];
    [self performSegueWithIdentifier:@"idSegueInsertarCata" sender:self];
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    self.id_Usuario = [[[self.arrayDatos objectAtIndex:indexPath.row] objectAtIndex:0]intValue];
    self.nombre_Usuario = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:1]];
    self.nombre_Avatar_Usuario = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: indexPath.row] objectAtIndex:4]];
    [self performSegueWithIdentifier:@"idSegueInsertarCata" sender:self];
}

- (void)didReceiveMemoryWarning
{
    
    [super didReceiveMemoryWarning];
}

//Prepara el segue del boton +//
- (IBAction)insertarUsuario:(id)sender
{
    [self performSegueWithIdentifier:@"idSegueDetalleUsuario" sender:self];
}

@end
