//
//  DetalleFinalCatas.m
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 13/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import "DetalleFinalCatas.h"
#import "GestorBD.h"

@interface DetalleFinalCatas ()

@property (nonatomic, strong) GestorBD *gestorBD;

- (IBAction) ocultarTeclado:(id)sender;

@end

@implementation DetalleFinalCatas

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.gestorBD = [[GestorBD alloc] initWithDatabaseFilename:@"vinos.sqlite"];
    self.usuario.text = self.nombre_Usuario_Detalle_NuevaCata;
    self.avatarUsuario.image = [UIImage imageNamed:self.nombre_Avatar];
   
    //PARA LA APLICACION 2
    
#ifdef VERSION2
    int clase1=1;
    
    if(self.at4.floatValue<=1.57){
        if(self.at7.floatValue<=3.8){
            clase1 = 2;
        }else{
            clase1 = 3;
        }
    }else{
        if(self.at1.floatValue<=12.77){
            clase1 = 2;
        }else{
            if(self.at4.floatValue<=2.11){
                clase1 = 2;
            }else{
                if(self.at7.floatValue<=3.4){
                    clase1 = 2;
                }else{
                    clase1 = 1;
                }
            }
        }
    }
    self.clase.selectedSegmentIndex=clase1-1;
    self.clase.userInteractionEnabled=NO;
#endif
    
    //PARA LA APLICACION 3
    
#ifdef VERSION3
    
    NSString *peticion = [NSString stringWithFormat:@"http://www.manelme.com/WekaWrapper/wine;attr1=%@;attr2=%@;attr3=%@;attr4=%@;attr5=%@;attr6=%@;attr7=%@;attr8=%@;attr9=%@",self.at1,self.at2,self.at3,self.at4,self.at5,self.at7,self.at8,self.at9,self.at10];
    
    NSURL *urlRequest = [NSURL URLWithString:peticion];
    NSError *err=@"";
    
    NSString *html = [NSString stringWithContentsOfURL:urlRequest encoding:NSUTF8StringEncoding error:&err];
    
    NSLog(html);
    NSLog(peticion);
    
    self.clase.selectedSegmentIndex= [html integerValue]-1;
    self.clase.userInteractionEnabled=NO;
    
#endif

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)guardarNuevaCata:(id)sender
{
    if (![self.nombreCata.text isEqualToString: @""])
    {
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        [df setDateFormat:@"dd-MM-yyyy"];
        NSString *fecha_cata = [df stringFromDate:self.fechaCata.date];
        
        NSString *consulta = [NSString stringWithFormat:@"insert into catas values (null, '%@', '%@', '%.2f', '%.2f', '%.2f', '%.2f', '%.2f', '%.2f', '%.2f', '%.2f', '%.2f', '%.2f', '%li','%i')", self.nombreCata.text, fecha_cata, self.at1.floatValue, self.at2.floatValue, self.at3.floatValue, self.at4.floatValue, self.at5.floatValue, self.at6.floatValue, self.at7.floatValue, self.at8.floatValue, self.at9.floatValue, self.at10.floatValue, self.clase.selectedSegmentIndex+1, self.id_Usuario_Detalle_NuevaCata];

        [self.gestorBD executeQuery:consulta];
        if (self.gestorBD.filasAfectadas !=0)
        {
            NSLog(@"Consulta ejecutada con ÉXITO...%d filas", self.gestorBD.filasAfectadas);
            [self.navigationController popViewControllerAnimated:YES];
            [self.navigationController popViewControllerAnimated:YES];
            [self.delegate2 editionDidFinished];
        }
        else
        {
            NSLog(@"No se ha podido ejecutar la consulta...repásala...");
        }
    }
    else
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Advertencia" message:@"Introduzca un nombre de Cata" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *accion = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
        {
            [alert dismissViewControllerAnimated:YES completion:nil];
        }];
        [alert addAction:accion];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

- (IBAction) ocultarTeclado:(id)sender
{
    [self.nombreCata resignFirstResponder];
}
@end
