//
//  ResumenCata.h
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 14/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResumenCata : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *claseFinal;
@property (weak, nonatomic) IBOutlet UITextField *nombreFinal;
@property (weak, nonatomic) IBOutlet UITextField *fechaFinal;
@property (weak, nonatomic) IBOutlet UILabel *usuarioFinal;
@property (weak, nonatomic) IBOutlet UIImageView *avatarFinal;

@property (nonatomic) int id_Resumen_Catas;
@property (nonatomic) NSString *nombre_Usuario_Resumen_Catas;
@property (nonatomic) NSString *nombre_Avatar_ResumenCata;

- (IBAction)volver:(id)sender;

@end
