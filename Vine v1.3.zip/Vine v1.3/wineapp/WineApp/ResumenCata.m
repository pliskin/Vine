//
//  ResumenCata.m
//  WineApp
//
//  Created by Francisco Jose Escamez Martin on 14/12/15.
//  Copyright © 2015 Francisco Jose Escamez Martin. All rights reserved.
//

#import "ResumenCata.h"
#import "GestorBD.h"
#import "CatasUsuario.h"

@interface ResumenCata ()

@property (nonatomic, strong) GestorBD *gestorBD;
@property (nonatomic, strong) NSArray *arrayDatos;

- (void) cargarResumen;

@end

@implementation ResumenCata

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.gestorBD = [[GestorBD alloc] initWithDatabaseFilename:@"vinos.sqlite"];
    self.avatarFinal.image = [UIImage imageNamed:self.nombre_Avatar_ResumenCata];
    [self cargarResumen];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

//Muestra los datos del Resumen de la Cata
- (void) cargarResumen
{
    self.usuarioFinal.text = self.nombre_Usuario_Resumen_Catas;
    NSString *consulta = [NSString stringWithFormat:@"select * from catas where id_cata=%i", self.id_Resumen_Catas];
    if (self.arrayDatos != nil) self.arrayDatos = nil;
    self.arrayDatos = [[NSArray alloc] initWithArray:[self.gestorBD selectFromDB:consulta]];
    self.nombreFinal.text = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: 0] objectAtIndex:1]];
    self.fechaFinal.text = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: 0] objectAtIndex:2]];
    self.claseFinal.text = [NSString stringWithFormat:@"%@", [[self.arrayDatos objectAtIndex: 0] objectAtIndex:13]];
}

- (IBAction)volver:(id)sender
{
}

@end
